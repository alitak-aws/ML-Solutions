import boto3
import datetime


REGION = boto3.session.Session().region_name
sm = boto3.client('sagemaker', region_name=REGION)


def create_endpoint_config(config_name, model_name):
    sm.create_endpoint_config(
        EndpointConfigName=config_name,
        ProductionVariants=[
            {
                'VariantName': 'prod',
                'ModelName': model_name,
                'InitialInstanceCount': 1,
                'InstanceType': 'ml.t2.medium'
            }
        ]
    )


def create_endpoint(endpoint_name, config_name):
    sm.create_endpoint(
        EndpointName=endpoint_name,
        EndpointConfigName=config_name
    )


def update_endpoint(endpoint_name, new_config_name):
    sm.update_endpoint(EndpointName=endpoint_name,
                EndpointConfigName=new_config_name
    )

def create_model(bucket, source_bucket, model_name, model_path, container, role):
    source_dir = f's3://{source_bucket}/entry-point/entry_deploy.tar.gz'
    print(f'source_dir {source_dir}')

    try:
        sm.create_model(
            ModelName=model_name,
            PrimaryContainer={
                'Image': container,
                'ModelDataUrl': f'{model_path}',
                'Environment': {
                    'SAGEMAKER_SUBMIT_DIRECTORY': source_dir,
                    'SAGEMAKER_PROGRAM': 'entrypoint.py',
                    'SAGEMAKER_REGION': 'us-west_2'
                }
            },
            ExecutionRoleArn=role
        )
    except Exception as e:
        print(f'Error while creating model {model_name}: {e}')
        raise(e)

def update_model_endpoint(bucket, source_dir, endpoint_name, model_path, container, role):
    model_name = f'model-{datetime.datetime.today().strftime("%Y-%m-%d-%H-%M-%S")}'
    config_name = f'config-{datetime.datetime.today().strftime("%Y-%m-%d-%H-%M-%S")}'
    create_model(bucket, source_dir, model_name, model_path, container, role)
    create_endpoint_config(config_name, model_name)
    # create_endpoint(endpoint_name, config_name)
    update_endpoint(endpoint_name, config_name)

def create_model_endpoint(bucket, source_dir, endpoint_name, model_path, container, role):
    model_name = f'model-{datetime.datetime.today().strftime("%Y-%m-%d-%H-%M-%S")}'
    config_name = f'config-{datetime.datetime.today().strftime("%Y-%m-%d-%H-%M-%S")}'
    create_model(bucket, source_dir, model_name, model_path, container, role)
    create_endpoint_config(config_name, model_name)
    # create_endpoint(endpoint_name, config_name)
    create_endpoint(endpoint_name, config_name)
