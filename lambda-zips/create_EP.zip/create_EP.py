# from dynamodb_helper import ResultsTable
import boto3
import os
import tarfile
import io
import json
import sys

# from boto3.dynamodb.conditions import Key, Attr
import datetime
import sagemaker_helper

role = os.getenv('role') 
container = os.getenv('container')
endpoint = os.getenv('endpoint') #'ali-5'
TABLE_NAME = os.getenv('TABLE_NAME') #'active-learning'
source_bucket = os.getenv('source_bucket') 

REGION = boto3.session.Session().region_name

s3 = boto3.client('s3', region_name=REGION)
sm = boto3.client('sagemaker', region_name=REGION)
s3_resource = boto3.resource('s3')

ddb = boto3.client('dynamodb')
ddb_resource = boto3.resource('dynamodb')


sagemaker = boto3.client('sagemaker')
INSTANCE_TYPE = 'ml.m4.xlarge'



CLF_COLS = ['label_1'] #'label_2' , 'label_3', 'label_4', 'label_5' ]



def lambda_handler(event, context):
    model_data_urls = event['model_data_url']
    table_name = TABLE_NAME
    

    
    model_paths = []
    new_metrics = []
    for url in model_data_urls:
        bucket = url.split('/')[2]
        key = url.split('/',3)[-1]
        prefix = ('/').join(key.split('/')[:2])
        
        print(f'prefix:  {prefix}', 'key, {key}')

        result_path = extract_model_contents(bucket, key)
        model_paths.append(url)
        new_metrics.append(parse_metrics(bucket, result_path) )
        
    new_metric = sum(new_metrics) / len(new_metrics) 

    # write metrics to DynamoDB
    response = ddb.describe_table(TableName=table_name)
    num_items = response['Table']['ItemCount']
    run_id = f'run-{num_items}'  # original will be stored as run-0
    # model_location = f'active-learning/{prefix}/endpoint/cls_model.tar.gz'

    model_location = create_endpoint_source(
        bucket,
        model_data_urls,
        'Raw-data', 
        f'clf'
    )
    print(f'model_location {model_location}')

    ddb_table = ddb_resource.Table(table_name)
    # scan_resp = ddb_table.scan( FilterExpression=Attr('isCurrentEP').eq(True) )
    
    # read item metrics from item which is the current endpoint
    # current_metrics = scan_resp['Items'][0]['classificationMetrics']

    ddb_table.put_item(
                Item={
                    'RunId': run_id,
                    'trainingDate': str(datetime.date.today()),
                    'Metrics': str(new_metric),
                    'ModelLocation': model_location,
                    'isCurrentEP': True
                }
            )

    # compare metrics and if metric is high, update isCurrentEndpoint
    # decision = compare_results(current_metrics, new_metric)


    # create endpoint
    try:
        sagemaker_helper.create_model_endpoint(
            bucket,
            source_bucket,
            endpoint,
            model_location,
            container,
            role
        )
        
        event['stage'] = 'DeploymentClassification'
        event['status'] = 'updating'
        event['message'] = 'Started deploying model  to endpoint "{}"'.format( endpoint)
            
        return {
            'statusCode': 200,
            'body': json.dumps('Results compared and stored in \
                DynamoDB. New model performs better, \
                endpoint is updated.')

        }

    except Exception as e:
        print(f'Exception occured : {e}')                    

    return event

def extract_model_contents(bucket_name, model_key):
    """
    Extract the model weights, results and
    vocab.txt for classification models
    """
    tar_file = s3.get_object(Bucket=bucket_name, Key=model_key)
    tar_content = tar_file['Body'].read()
    result_path = f"{('/').join(model_key.split('/')[:5])}/model"

    tar = tarfile.open(fileobj=io.BytesIO(tar_content))
    
    files = tar.getnames()
    for file in files:
        temp_file = tar.extractfile(file)
        temp_key = f'{result_path}/{file}'
        s3.put_object(Body=temp_file, Bucket=bucket_name, Key=temp_key)
        
    print(f'Files extracted from model.tar.gz and uploaded to s3://{bucket_name}/{result_path}')

    return result_path


def parse_metrics(bucket_name, file_key):
    """
    Parse through eval_COL.json from the models for each field
    and return the mean of f1_micro
    """
    
    paginator = s3.get_paginator('list_objects_v2')
    response_iterator = paginator.paginate(Bucket=bucket_name, Prefix=file_key)
    
    for response in response_iterator:
        for object_data in response['Contents']:
            key = object_data['Key']
            if key.endswith('.json'):
                file_name = key
                
    print(f'********** file_name: {file_name}')
    
    resp_obj = s3.get_object(Bucket=bucket_name, Key=file_name )
    eval_results = resp_obj['Body'].read().decode('utf-8')
    
        
    return json.loads(eval_results)['f1_micro']

def compare_results(old_metrics, new_metrics):
    return 'retain' if float(old_metrics) >  new_metrics else 'update'
    
def create_endpoint_source(bucket_name, model_paths, source_key, target_path):
    """
    For the current retrained model, create a tar.gz file to
    use in the model endpoint configuration
    Inputs:
    bucket_name(str), prefix(str): location of the vocab.txt and features.npz 
    Output:
    tar.gz file
    """

    for url in model_paths: #model_paths
        col = url.split(r'/',6)[-2]
        path = url.rsplit(r'/',3)[0].split('/',3)[-1]
        print(os.listdir('/tmp'))
        
        s3.download_file(bucket_name, os.path.join(path, f'{col}_xgboost.model'), f'/tmp/{col}_xgboost.model')
        
        
    s3.download_file(bucket_name, os.path.join('Raw-data', 'features.npz'), '/tmp/features.npz')
    s3.download_file(bucket_name, os.path.join('Raw-data', 'vocab.txt'), '/tmp/vocab.txt')
    s3.download_file(bucket_name, os.path.join('Raw-data', 'dic.json'), '/tmp/dic.json')


    tar = tarfile.open("/tmp/clf_model.tar.gz", "w:gz")
    for file in os.listdir('/tmp/'):
        if file.endswith('.model') or file.endswith('dic.json') or\
                file.endswith('vocab.txt') or file.endswith('.npz'):
            print('file_added: ', file)
            tar.add(f'/tmp/{file}', f'{file}')
    tar.close()

    target_key = f'{target_path}/clf_model.tar.gz'
    s3_resource.meta.client.upload_file('/tmp/clf_model.tar.gz',
                                        bucket_name,
                                        target_key)

    return f's3://{bucket_name}/{target_key}'
