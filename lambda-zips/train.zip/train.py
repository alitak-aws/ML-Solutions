import boto3
import json
import os
import time

role = os.getenv('role') 
container = os.getenv('container')
bucket_name = os.getenv('BUCKET_NAME')
source_bucket = os.getenv('source_bucket')

REGION = boto3.session.Session().region_name

s3 = boto3.client('s3', region_name=REGION)
sm = boto3.client('sagemaker', region_name=REGION)

CLF_COLS = [
    'label_1', #'label_2' , 'label_3', 'label_4', 'label_5'
    ]

LABELS = {
 'label_1': 2, #'label_2': 2 , 'label_3': 3, 'label_4': 2, 'label_5': 5
    }


def lambda_handler(event, context):
    
    entry_point_dir = f's3://{source_bucket}/entry-point/entrypoint_training.tar.gz'
    
    all_job_names = []
    
    # start training
    for col in CLF_COLS:

        # This is to make sure the job_names will be different
        time.sleep(2)
        isNew = event["Arguments"]["--isNew"]
        print(f'vesrion: {isNew}')


        job_name = 'cls-' + time.strftime("%Y-%m-%d-%H-%M-%S", time.gmtime())
        print('*****', col, job_name)

        training_channel = f's3://{bucket_name}/features_{isNew}/train_eval/{col}/data/npz/train'
        validation_channel = f's3://{bucket_name}/features_{isNew}/train_eval/{col}/data/npz/validation'
        output_path = f's3://{bucket_name}/features_{isNew}/train_eval/{col}/data/npz/model'

        input_data_config = [
            {'ChannelName': 'train',
              'DataSource': {
                  'S3DataSource': {'S3DataType': 'S3Prefix',
                  'S3Uri': training_channel,
                  'S3DataDistributionType': 'FullyReplicated'}
                            },
                  'CompressionType': 'None',
                  'RecordWrapperType': 'None'
            },
          {'ChannelName': 'validation',
              'DataSource': {
                  'S3DataSource': {'S3DataType': 'S3Prefix',
                  'S3Uri': validation_channel,
                  'S3DataDistributionType': 'FullyReplicated'}
                                  },
                  'CompressionType': 'None',
                  'RecordWrapperType': 'None'
          }
        ]

        output_data_config = {
            'KmsKeyId': '',
            'S3OutputPath': output_path
        }

        hyperparams = {
         'field_name': col,
         'num_class': str(LABELS[col]),
         'sagemaker_container_log_level': '20',
         'sagemaker_enable_cloudwatch_metrics': 'true',
         'sagemaker_program': 'xgb_script.py',
         'sagemaker_submit_directory': entry_point_dir 
        } 
        
        event["container"] = container
        event["stage"] = "TrainingClassification"
        event["status"] = "InProgress"
        all_job_names.append(job_name)

        resp = sm.create_training_job(
            TrainingJobName=job_name, 
            AlgorithmSpecification={'TrainingImage': container,
                                  'TrainingInputMode': 'File',
                                  'EnableSageMakerMetricsTimeSeries': False
                                    }, 
            RoleArn=role,
            InputDataConfig=input_data_config , 
            OutputDataConfig=output_data_config,
            ResourceConfig={'InstanceType': 'ml.m4.xlarge',
                              'InstanceCount': 1,
                              'VolumeSizeInGB': 30
                            }, 
            StoppingCondition={'MaxRuntimeInSeconds': 86400},
            HyperParameters=hyperparams
        )
    event['name'] = all_job_names
    
    print(event)

    return event