# coding=utf-8
# Copyright 2020 AWS Data Scientist Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""" This is the classification training script used on SageMaker
for xgboost algorithms """

from __future__ import print_function

import argparse
import os
import pandas as pd
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, classification_report
import scipy.sparse
import json
import xgboost as xgb

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # Sagemaker specific arguments. Defaults are set in the environment variables.
    parser.add_argument('--output-data-dir', type=str, default=os.environ['SM_OUTPUT_DATA_DIR'])
    parser.add_argument('--model-dir', type=str, default=os.environ['SM_MODEL_DIR'])
    parser.add_argument('--train', type=str, default=os.environ['SM_CHANNEL_TRAIN'])
    parser.add_argument('--validation', type=str, default=os.environ['SM_CHANNEL_VALIDATION'])
    parser.add_argument('--num_class', type=int)
    parser.add_argument('--field_name', type=str)
    

    args = parser.parse_args()

    # Take the set of files and read them all into a single pandas dataframe
    train_data = scipy.sparse.load_npz(os.path.join(args.train, 'train.npz'))
    test_data = scipy.sparse.load_npz(os.path.join(args.validation, 'validation.npz'))
    # labels are in the first column
    train_y = train_data[:, 0].toarray().squeeze()
    train_X = train_data[:, 1:]

    test_y = test_data[:, 0].toarray().squeeze()
    test_X = test_data[:, 1:]
    
    dtrain = xgb.DMatrix(train_X, label=train_y)
    dtest = xgb.DMatrix(test_X, label=test_y)
    params={
        'max_depth':5,
        'eta':0.2,
        'gamma':4,
        'min_child_weight':6,
        'subsample':0.8,
        'silent':0,
        'objective':"multi:softmax", ###softprob
        'num_class':args.num_class,
        'num_round':5
    }

    # train
    num_round = 10
    watchlist = [(dtest, 'eval'), (dtrain, 'train')]
    bst = xgb.train(params, dtrain, num_round, watchlist)
    
    pred_y = bst.predict(xgb.DMatrix(test_X))
    
    eval_results = {
        'precision_macro': precision_score(test_y, pred_y, average='macro'),
        'precision_micro': precision_score(test_y, pred_y, average='micro'),
        'recall_macro': recall_score(test_y, pred_y, average='macro'),
        'recall_micro': recall_score(test_y, pred_y, average='micro'),
        'f1_macro': f1_score(test_y, pred_y, average='macro'),
        'f1_micro': f1_score(test_y, pred_y, average='micro'),
        'accuracy': accuracy_score(test_y, pred_y)
    }
    
    print('evaluation')
    print(eval_results)
    print('*********')
    print('Classification_report: ')
#     print(classification_report(test_y, pred_y, target_names = ['Not_Rare', 'Rare']))
    
    # Emit f1 to match metric pattern
    # pattern = .*\[[0-9]+\].*#011train-f1:([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?).*
    f1_micro = eval_results['f1_micro']
    print(f'[1]#011train-f1:{f1_micro}')
    
    with open(os.path.join(args.model_dir, "eval.json"), 'w') as f:
        json.dump(eval_results, f)
    # save prediction
#     pred_df = pd.DataFrame({'true_y':test_y, 'pred_y':pred_y})
#     pred_df.to_csv( os.path.join(args.model_dir, "prediction.csv"), index=False, header=True )

    # Print the coefficients of the trained classifier, and save the coefficients
    
    col = args.field_name
    
    bst.save_model(os.path.join(args.model_dir, f"{col}_xgboost.model"))


def model_fn(model_dir):
    """Deserialized and return fitted model

    Note that this should have the same name as the serialized model in the main method
    """
    bst = xgb.Booster({'nthread': 4})  # init model
    bst.load_model(os.path.join(model_dir, "xgboost.model"))  # lo
    
    return bst

