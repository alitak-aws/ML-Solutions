# coding=utf-8
# Copyright 2020 AWS Data Scientist Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""" Data preprocessing for Bert NER training and evaluation

This script is used to prepare and preprocess the data into Bert format
in order to be used for training and evaluation on NER task.
"""

import json
import spacy
import torch

import numpy as np
from transformers import BertTokenizer
from spacy.gold import biluo_tags_from_offsets

import en_core_web_sm
nlp = en_core_web_sm.load()

# nlp = spacy.load("en_core_web_sm", disable=['ner', 'parser'])


def offset_2_iob(text, entities, matchENT):
    """
    convert offset annotated sentence into IOB format

    Args:
        text (str): the raw text of a sentence
        entities (list): a list of entities. Each entity is in form of (start_offset, end_offset, entity_type)
        matchENT (str): the entity type to match

    Returns:
        tuple: (words, labels) which are in IOB format

    """

    ents = []
    for start,end,type in entities:
        if type == matchENT:
            ents.append( [start, end, type , True ] )
    words = []
    labels = []
    doc = nlp(text)
    for token in doc:
        outside = True
        word = token.text.lower()
        words.append( word )

        start, end = token.idx, token.idx + len(word)
        for ent in ents:
            if start < ent[1] and ent[0] < end:
                outside = False
                if ent[3] == True:
                    labels.append('B-{}'.format(ent[2]))
                    ent[3] = False
                else:
                    labels.append('I-{}'.format(ent[2]))
                break

        if outside:
            labels.append('O')

    assert len(labels)==len(words), f'labels and words length not equal. Sent:{text}, Entities:{entities}'
    return words, labels


def spacyoffset_2_iob(data, ent_types):
    """
    convert spacy offset format to IOB format

    Args:
        data (object): spacy NER task input format
        ent_types (list): the list of entities to export to IOB format

    Returns:
        dictionary: {'words':[], 'labels':[]} in IOB format

    """

    iob = {'words':[], 'labels':[]}
    for i,row in enumerate(data):
        if i % 2000 == 999:
            print(f'processing {i+1} in {len(data)}')

        all_labels = []
        for ent_type in ent_types:

            words, labels = offset_2_iob( row[0], row[1]['entities'], ent_type)
            if ent_type in row[1]['IGNORE']:
                labels = ['IGNORE'] * len(labels)
            all_labels.append(labels)

        iob['words'].append(words)
        iob['labels'].append(all_labels)

    return iob


def split_seq(seq, max_length):
    """ split sequence based on Bert max sequence length """

    seq_len = len(seq)
    sequences = []

    if seq_len <= max_length:
        sequences.append( seq )
    else:
        end_idx = max_length
        while end_idx < seq_len:
            sequences.append( seq[end_idx-max_length : end_idx] )
            end_idx += max_length
        sequences.append( seq[seq_len-max_length:seq_len] )

    return sequences


def iob_2_berttokens(words, listoflabels, tokenizer, pad_token_label_id, max_length, label_map):
    """
    convert a sentence in IOB format into bert format

    Args:
        words (list): a list of simple tokens for the sentence
        listoflabels (list of lists): a list of lists where each list is a label sequence for corresponding entity type
        tokenizer (object): bert tokenizer
        pad_token_label_id (int): an int number indicating the corresponding token will be ignored and not contribute
        to the cross entropy loss.
        max_length (int): max length of sequence
        label_map (dic): a map that converts labels into integers.

    Returns:
        tuple: (tokens, labels) where tokens and labels are in bert format.

    """
    tokens = []
    all_label_ids = [[] for n in listoflabels]

    for i,word in enumerate(words):
        word_tokens = tokenizer.tokenize(word)
        tokens.extend(word_tokens)
        if len(tokens) > 0: #there were some empty tokens that resulted in assertion errors
            for j in range(len(all_label_ids)):
                all_label_ids[j].extend([label_map[listoflabels[j][i]]] + [pad_token_label_id]*(len(word_tokens) -1))

    for j in range(len(all_label_ids)):
        assert len(tokens) == len(all_label_ids[j])

    sents_token = split_seq(tokens, max_length)
    sents_alllabel = [[] for n in sents_token ]
    for label_ids in all_label_ids:
        sents_label = split_seq( label_ids, max_length)
        for i,sent_label in enumerate(sents_label):
            sents_alllabel[i].append(sent_label)

    assert len(sents_token) == len(sents_alllabel)
    for sent_alllab in sents_alllabel:
        assert  len(sent_alllab) == len(listoflabels)

    return sents_token, sents_alllabel


def iob_2_bertfeatures(save_file, iobdata, tokenizer,  pad_token_label_id, max_length, label_map):
    """
    convert a list of sentences in IOB format to Bert format.

    Args:
        save_file (str): a npz file name for a file to save bert features
        iobdata (dic): a dictionary in form of {'words':[], 'labels':[]}, where 'words' is a list of lists of tokens,
        and 'labels' is a list of lists of labels.
        tokenizer (object): bert tokenizer
        pad_token_label_id (int): an int number indicating the corresponding token will be ignored and not contribute
        to the cross entropy loss.
        max_length (int): bert max sequence length
        label_map (dic): a map converting labels to integers

    Returns:
        Dataset: a pytorch tensorDataset which can generate batches of input to the bert model.

    """

    pad_token = tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0]
    all_input_ids=[]
    all_input_mask=[]
    all_segment_ids = []
    all_label_ids=[]

    for words, listoflabels in zip(iobdata['words'], iobdata['labels']):
        # per sentence split
        sents_token, sents_labelid = iob_2_berttokens(words, listoflabels, tokenizer, pad_token_label_id, max_length-2, label_map)
        for tokens, label_ids in zip(sents_token, sents_labelid):
            # per sentences
            tokens = [ tokenizer.cls_token ] + tokens[:] + [ tokenizer.sep_token ]
            #label_ids = [pad_token_label_id] + label_ids[:] + [pad_token_label_id]
            label_ids = [ [pad_token_label_id] + per_label_ids[:] + [pad_token_label_id] for per_label_ids in label_ids ]
            segment_ids = [0] * len(tokens)
            input_ids = tokenizer.convert_tokens_to_ids(tokens)
            input_mask = [1] * len(input_ids)
            padding_length = max_length - len(input_ids)
            #pad
            input_ids += ([pad_token] * padding_length)
            input_mask += ([0] * padding_length)
            segment_ids += ([0] * padding_length)
            #label_ids += ([pad_token_label_id] * padding_length)
            label_ids = [ per_label_ids[:]+[pad_token_label_id] * padding_length for per_label_ids in label_ids]

            assert len(input_ids) == max_length
            assert len(input_mask) == max_length
            assert len(segment_ids) == max_length
            for per_label_ids in label_ids:
                assert len(per_label_ids) == max_length
            all_input_ids.append(input_ids)
            all_input_mask.append(input_mask)
            all_segment_ids.append(segment_ids)
            all_label_ids.append(label_ids)

    np.savez(save_file,
             all_input_ids= np.array(all_input_ids, dtype=int),
             all_input_mask = np.array(all_input_mask , dtype=int),
             all_segment_ids = np.array(all_segment_ids, dtype=int),
             all_label_ids = np.array(all_label_ids, dtype=int)
             )

    return all_input_ids, all_input_mask, all_segment_ids, all_label_ids
