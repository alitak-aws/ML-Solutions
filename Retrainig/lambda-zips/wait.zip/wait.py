import json
import boto3
import os

role = 'arn:aws:iam::770499558699:role/workshop-role' 
REGION = boto3.session.Session().region_name

s3 = boto3.client('s3', region_name=REGION)
sagemaker = boto3.client('sagemaker', region_name=REGION)



def lambda_handler(event, context):

    complete_flag=True
    stage = event['stage']
    if stage == 'TrainingClassification':
        training_jobs = event['name']
        
        message = ''
        model_data_url=[]
        
        # make sure all jobs are complete
        for job in training_jobs:
            response = describe_training_job(job)
            status = response['TrainingJobStatus']
            if status not in ['Completed', 'Failed']:
                complete_flag=False
                
            else:
                if status == 'Failed':
                    complete_flag = False
                    event['status'] = 'Failed'
                    event['message'] = f'Training job {job} failed. Stopping pipeline, check CloudWatch logs.'                
            
                
        if complete_flag == True:
            for job in training_jobs:
                response = describe_training_job(job)
                status = response['TrainingJobStatus']
                if status == 'Completed':
                    model_artifact = response.get('ModelArtifacts',{}).get('S3ModelArtifacts','')
                    if model_artifact=='':
                        message = message + f'No model artifact found for {job}, check logs. '
                    else:
                        model_data_url.append(model_artifact)
                        message = message + f' Training Job {job} complete. Model uploaded to {model_artifact}. '
                elif status == 'Failed':
                    failure_reason = response['FailureReason']
                    message = message + 'Training job failed, reason - {failure_reason}. '
            
            event['message'] = message
            event['status'] = 'Completed'
            event['model_data_url'] = model_data_url
                    
    elif stage == 'DeployClassification':
        endpoint_name = event['name']
        endpoint_details = describe_endpoint(endpoint_name)
        status = endpoint_details['EndpointStatus']
        if status == 'InService':
            event['message'] = f'Deployment completed for {endpoint_name} endpoint.'
        elif status == 'Failed':
            failure_reason = endpoint_details['FailureReason']
            event['message'] = f'Deployment failed for {endpoint_name} with error {failure_reason}'
        elif status == 'RollingBack':
            event['message'] = 'Deployment failed for {endpoint_name} endpoint,\
            rolling back to previously deployed version.'
        event['status'] = status

    return event


def describe_training_job(name):
    """ 
    Describe SageMaker training job identified by input name.
    Args:
        name (string): Name of SageMaker training job to describe.
    Returns:
        (dict)
        Dictionary containing metadata and details about the status of the training job.
    """
    try:
        response = sagemaker.describe_training_job(
            TrainingJobName=name)
    except Exception as e:
        print(f'Unable to describe hyperparameter tunning job. Exception: {e}')
        raise(e)
    return response


def describe_endpoint(name):
    """
    Describe SageMaker endpoint identified by input name.
    Args:
        name (string): Name of SageMaker endpoint to describe.
    Returns:
        (dict)
        Dictionary containing metadata and details about the status of the endpoint.
    """
    try:
        response = sagemaker.describe_endpoint(
            EndpointName=name
        )
    except Exception as e:
        print(f'Unable to describe endpoint. Exception: {e}')
        raise(e)
    return response