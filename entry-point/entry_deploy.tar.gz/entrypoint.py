# coding=utf-8
# Copyright 2020 AWS Data Scientist Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""" Deploy Classification models on SageMaker endpoint

This script is the entry point used to deploy all classification models into a single
Sagemaker endpoint.
 """

import os
import tokenization
import logging
import json
import pandas as pd
import numpy as np
import scipy.sparse as sp
from sklearn.externals import joblib
import xgboost as xgb
# from nltk.tokenize import sent_tokenize
import re

import en_core_web_sm
nlp = en_core_web_sm.load()


logger = logging.getLogger(__name__)

CLF_COLS = [
    'label_1' #, 'label_2' , 'label_3', 'label_4', 'label_5'
    ]

prefix_model = '/opt/ml/model'
prefix_code = '/opt/ml/code'

print('******** code **********')
for file in os.listdir('/opt/ml/code'):
    print(file)
print('******************')

print('******** model **********')
for file in os.listdir('/opt/ml/model'):
    print(file)
print('******************')

#inital DIC
with open( os.path.join(prefix_code, 'dic.json') , 'r') as f:
    DIC = json.load(f)

#inital tokenizer
WordPiece_tokenizer = tokenization.FullTokenizer(vocab_file= os.path.join(prefix_model, 'vocab.txt'),do_lower_case=True)


def wordpiece_2_ngrams(text, ngram):
    """
    Use wordpiece tokenizer to tokenizer a piece of raw text
    and return all the possible grams.

    Args:
        text (str): a piece of raw texr
        ngram (int): number of gram to consider

    Returns:
        list: a list of possible grams

    """

    doc = WordPiece_tokenizer.tokenize(text)
    grams = []

    for s in range(len(doc)):
        for e in range(s, min(s + ngram, len(doc))):
            tokens = doc[s:e + 1]
            grams.append( ' '.join( [ token for token in tokens ] ) )

    return grams

#inital tfidf vector encoder
class BOWencoder(object):
    """Loads a pre-weighted tfidf table.
    Convert new text to tfidf vector.
    """

    def __init__(self, tfidf_path=None):
        """
        Args:
            tfidf_path (str): path to saved model file
        """
        # Load from disk
        logger.info('Loading %s' % tfidf_path)
        source_data = np.load(tfidf_path, allow_pickle=True)
        self.doc_freqs = source_data['meta'].item()['Ns'] # np.array: shape (num_of_terms,)
        self.num_docs = len(source_data['meta'].item()['Doc2idx'])
        self.ngram = source_data['meta'].item()['ngram']
        self.Term2idx = source_data['meta'].item()['Term2idx']
        self.tokenizer = wordpiece_2_ngrams


    def text2spvec(self, query):
        """Create a sparse tfidf-weighted word vector from query.
        tfidf = log(tf + 1) * log((N - Nt + 0.5) / (Nt + 0.5))
        """
        # Get hashed ngrams
        grams = self.tokenizer(query,ngram=self.ngram)
        wids = [ self.Term2idx[gram] for gram in grams if gram in self.Term2idx ]

        if len(wids) == 0:
            logger.warning('No valid word in: %s' % query)
            return sp.csr_matrix( (1, len(self.Term2idx) ) )

        # Count TF
        wids_unique, wids_counts = np.unique(wids, return_counts=True)
        tfs = np.log1p(wids_counts)

        # Count IDF
        Ns = self.doc_freqs[wids_unique]
        idfs = np.log((self.num_docs - Ns + 0.5) / (Ns + 0.5))
        idfs[idfs < 0] = 0

        # TF-IDF
        data = np.multiply(tfs, idfs)

        # One row, sparse csr matrix
        indptr = np.array([0, len(wids_unique)])
        spvec = sp.csr_matrix(
            (data, wids_unique, indptr), shape=(1, len(self.Term2idx) )
        )

        return spvec

ENCODER = BOWencoder( os.path.join(prefix_model, 'features.npz') )




# pipeline functions

def input_fn(request_body, request_content_type):
    """ input function used by SageMaker endpoint """

    if request_content_type != 'application/json':
        raise TypeError(f'Unknown request type {request_content_type}')
    features = {} ####
    
    data = json.loads(request_body)
    text = data['text'].lower().replace('\n', '')
    features['encoded'] = ENCODER.text2spvec(text)  #########
    features['text'] = text  ############

    return features

def model_fn(model_dir):
    """ model function used by SageMaker endpoint """

    models = {}
    for field in CLF_COLS:
#         nbayes_path = os.path.join(model_dir, f'{field}.joblib') ###
        xgboost_path = os.path.join(model_dir, f'{field}_xgboost.model')

#         if os.path.isfile(nbayes_path): ##
#             models[field] = (joblib.load(nbayes_path), 'nbayes') ##
#         else: ##
        bst = xgb.Booster({'nthread': 4})
        bst.load_model(xgboost_path)
        models[field] = (bst , 'xgboost')

    return models

def predict_fn(input_object, model):
    """ prediction function used by SageMaker endpoint """

    features = input_object['encoded']
    text = input_object['text']
    
    models = model
    results = {}
    for field, (modl,md_tp) in models.items():
        pred_y = modl.predict(xgb.DMatrix(features))
        best_preds = pred_y #np.asarray([np.argmax(line) for line in pred_y]) ###
        results[field] = {}   
        results[field]['value'] = DIC[field][ str(int(best_preds[0])) ]
        # results[field]['confidence'] = str(pred_y[0].max() ) ###


    return results

def output_fn(prediction, response_content_type):
    """ output function used by SageMaker endpoint """

    return json.dumps(prediction)

